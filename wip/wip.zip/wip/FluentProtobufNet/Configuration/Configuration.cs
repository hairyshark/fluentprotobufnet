using ProtoBuf.Meta;

namespace FluentProtobufNet.Configuration
{
    public class Configuration
    {
        public RuntimeTypeModel RuntimeTypeModel { get; set; }
    }
}