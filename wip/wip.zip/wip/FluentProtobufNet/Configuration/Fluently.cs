namespace FluentProtobufNet.Configuration
{
    public class Fluently
    {
        public static FluentConfiguration Configure()
        {
            return new FluentConfiguration();
        }
    }
}