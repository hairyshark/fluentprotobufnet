﻿using FluentProtobufNet.Helpers;
using FluentProtobufNet.Mapping;

namespace FluentProtobufNet.Tests
{
//    public class CategoryMap : ClassMap<Category>
//    {
//        public CategoryMap()
//        {
//            this.BuildUp<CategoryMap, Category>(SeededIndexor.GetIndex);
//        }
//    }
//
//    public class CategoryWithDescriptionMap : SubclassMap<CategoryWithDescription>
//    {
//        public CategoryWithDescriptionMap(int discriminator)
//        {
//            this.DynamicSubclassMap<CategoryWithDescriptionMap, CategoryWithDescription>(discriminator, SeededIndexor.GetIndex);
//        }
//    }
//
//    public class CategoryThirdLevelMap : SubclassMap<CategoryThirdLevel>
//    {
//        public CategoryThirdLevelMap(int discriminator)
//        {
//            this.DynamicSubclassMap<CategoryThirdLevelMap, CategoryThirdLevel>(discriminator, SeededIndexor.GetIndex);
//        }
//    }
//
//    public class ItemMap : ClassMap<Item>
//    {
//        public ItemMap()
//        {
//            this.BuildUp<ItemMap, Item>(SeededIndexor.GetIndex);
//        }
//    }
}
