using ProtoBuf.Meta;

namespace FluentProtobufNet
{
    public class Configuration
    {
        public RuntimeTypeModel RuntimeTypeModel { get; set; }
    }
}