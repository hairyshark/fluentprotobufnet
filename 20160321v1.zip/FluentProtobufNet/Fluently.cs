using ProtoBuf.Meta;

namespace FluentProtobufNet
{
    public class Fluently
    {
        public static FluentConfiguration Configure()
        {
            return new FluentConfiguration();
        }
    }
}