namespace FluentProtobufNet.Mapping
{
    public interface IMapBaseClasses
    {
    }
}