namespace FluentProtobufNet.Mapping
{
    public interface IMapSubClasses
    {
    }
}