﻿namespace TradeReaderService
{
    /// <summary>
    /// The TradeReader interface.
    /// </summary>
    public interface ITradeReader : IRepository<int>
    {
    }
}