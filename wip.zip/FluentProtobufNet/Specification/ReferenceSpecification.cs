namespace FluentProtobufNet.Specification
{
    using System;
    using System.Reflection;

    public class ReferenceSpecification<TMessage> : ISpecification<PropertyInfo>
        where TMessage : class
    {
        public ReferenceSpecification()
        {
            this.DynamicType = typeof(TMessage).FullName;
        }

        public string DynamicType { get; set; }

        public bool IsSatisfied(PropertyInfo type)
        {
            var fullName = type.PropertyType.FullName;

            var isSatisfied = fullName.Equals(this.DynamicType);

            if (isSatisfied)
            {
                Console.WriteLine("satisfied with " + type.Name + "on message " + this.DynamicType);
            }

            return isSatisfied;
        }
    }
}